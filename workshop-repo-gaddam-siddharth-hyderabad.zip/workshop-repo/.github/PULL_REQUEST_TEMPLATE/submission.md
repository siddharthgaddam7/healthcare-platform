# Vibe Coding Workshop — Submission PR

## Title
[Hyderabad] Gaddam Siddharth — Vibe Coding Submission

---

## Participant Details
- **Name:** Gaddam Siddharth
- **City:** Hyderabad
- **Branch:** `participant/gaddam-siddharth-hyderabad`
- **Test File Used:** `test_hyderabad.csv`

---

## UC-0A — Complaint Classifier

**What it does:** Reads `test_hyderabad.csv`, classifies each complaint by category (Roads/Water/Sanitation/Electricity/Other) and severity (Low/Medium/High/Critical), writes `results_hyderabad.csv`.

**CRAFT loop summary:**
- Initial version had no severity escalation for safety keywords
- Fixed: Added Critical override for injury/child/school/hospital/death keywords — severity blindness issue

**Commit message:**
```
UC-0A Fix severity blindness: no keywords in enforcement → added injury/child/school/hospital triggers
```

**Output file:** `data/city-test-files/results_hyderabad.csv` ✅

---

## UC-0B — Summary That Changes Meaning

**What it does:** Reads `policy_hr_leave.txt`, extracts every numbered clause, produces `summary_hr_leave.txt` preserving all numbers, conditions, and mandatory language.

**CRAFT loop summary:**
- Initial version collapsed multiple clauses into one paragraph
- Fixed: Enforced per-clause extraction and clause-completeness rule — every numbered clause must appear

**Commit message:**
```
UC-0B Fix clause omission: completeness not enforced → added every-numbered-clause rule
```

**Output file:** `summary_hr_leave.txt` ✅

---

## UC-0C — Number That Looks Right

**What it does:** Reads `ward_budget.csv`, computes growth % per ward per category (never aggregated), writes `growth_output.csv`.

**CRAFT loop summary:**
- Identified silent aggregation anti-pattern (summing totals before computing growth)
- Fixed: Enforced per-row computation with explicit scope restriction in skills.md and code

**Commit message:**
```
UC-0C Fix silent aggregation: no scope in enforcement → restricted to per-ward per-category only
```

**Output file:** `growth_output.csv` ✅

---

## UC-X — Ask My Documents

**What it does:** Answers questions about 3 policy documents using keyword-based retrieval. Single-source only — no cross-document blending.

**CRAFT loop summary:**
- Initial design could return answers from wrong document
- Fixed: Added single-source attribution enforcement — each answer cites one document; "Not found" if absent

**Commit message:**
```
UC-X Fix cross-doc blending: no single-source rule → added single-source attribution enforcement
```

**Output file:** `app.py` runs without crash ✅

---

## Checklist
- [x] `agents.md` + `skills.md` committed for all 4 UCs
- [x] `classifier.py` runs on `test_hyderabad.csv`, produces `results_hyderabad.csv`
- [x] `app.py` for UC-0B, UC-0C, UC-X — each runs without crash
- [x] `growth_output.csv` present
- [x] `summary_hr_leave.txt` present
- [x] 4+ commits with meaningful messages, one per UC
- [x] PR template fully filled

---

## Notes for Reviewer
All CRAFT refinements are documented in each UC's `agents.md` (Enforcement Rules section) and `skills.md` (CRAFT Notes + Anti-Pattern sections). Commit history shows one fix per UC in chronological order.
