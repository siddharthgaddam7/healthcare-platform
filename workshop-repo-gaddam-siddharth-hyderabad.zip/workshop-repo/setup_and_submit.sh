#!/bin/bash
# ══════════════════════════════════════════════════════════════════════
#  Vibe Coding Workshop — Git Setup & Commit Script
#  Participant: Gaddam Siddharth | City: Hyderabad
#  Run this from inside your cloned fork of the workshop repo
# ══════════════════════════════════════════════════════════════════════

set -e  # Exit on any error

BRANCH="participant/gaddam-siddharth-hyderabad"

echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 1 — Verify environment"
echo "══════════════════════════════════════════════════════"
python --version
git --version
python -c "import csv, json; print('  ✅ csv + json: Ready')"

echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 2 — Create your branch"
echo "══════════════════════════════════════════════════════"
# Check if branch already exists
if git show-ref --verify --quiet refs/heads/$BRANCH; then
  echo "  Branch '$BRANCH' already exists — switching to it"
  git checkout $BRANCH
else
  git checkout -b $BRANCH
  echo "  ✅ Branch created: $BRANCH"
fi

echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 3 — Verify data files"
echo "══════════════════════════════════════════════════════"
for f in data/city-test-files/test_hyderabad.csv data/budget/ward_budget.csv \
          data/policy-documents/policy_hr_leave.txt \
          data/policy-documents/policy_it_acceptable_use.txt \
          data/policy-documents/policy_finance_reimbursement.txt; do
  if [ -f "$f" ]; then
    echo "  ✅ $f"
  else
    echo "  ⚠  MISSING: $f"
  fi
done

echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 4 — Run all UCs to generate output files"
echo "══════════════════════════════════════════════════════"
echo "  Running UC-0A..."
python uc-0a/classifier.py
echo "  Running UC-0B..."
python uc-0b/app.py
echo "  Running UC-0C..."
python uc-0c/app.py
echo "  Running UC-X..."
python uc-x/app.py
echo "  ✅ All UCs ran successfully"

echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 5 — Verify output files exist"
echo "══════════════════════════════════════════════════════"
for f in data/city-test-files/results_hyderabad.csv summary_hr_leave.txt growth_output.csv; do
  if [ -f "$f" ]; then
    echo "  ✅ $f"
  else
    echo "  ❌ MISSING: $f — check your app.py"
  fi
done

echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 6 — Stage and commit all 4 UCs"
echo "══════════════════════════════════════════════════════"

git add uc-0a/
git commit -m "UC-0A Fix severity blindness: no keywords in enforcement → added injury/child/school/hospital triggers"

git add uc-0b/
git commit -m "UC-0B Fix clause omission: completeness not enforced → added every-numbered-clause rule"

git add uc-0c/
git commit -m "UC-0C Fix silent aggregation: no scope in enforcement → restricted to per-ward per-category only"

git add uc-x/
git commit -m "UC-X Fix cross-doc blending: no single-source rule → added single-source attribution enforcement"

git add data/ summary_hr_leave.txt growth_output.csv .github/ || true
git commit -m "UC-ALL Add data files, outputs, and PR template" || echo "  (nothing extra to commit)"

echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 7 — Push to GitHub"
echo "══════════════════════════════════════════════════════"
echo ""
echo "  Run this command:"
echo ""
echo "    git push origin $BRANCH"
echo ""
echo "══════════════════════════════════════════════════════"
echo "  STEP 8 — Open your Pull Request"
echo "══════════════════════════════════════════════════════"
echo ""
echo "  1. Go to your forked repo on GitHub"
echo "  2. Click 'Compare & pull request' for branch: $BRANCH"
echo "  3. Set base repo: upstream main"
echo "  4. Title: [Hyderabad] Gaddam Siddharth — Vibe Coding Submission"
echo "  5. Copy content from: .github/PULL_REQUEST_TEMPLATE/submission.md"
echo "  6. Submit!"
echo ""
echo "  ✅ All done — good luck Gaddam Siddharth! 🚀"
